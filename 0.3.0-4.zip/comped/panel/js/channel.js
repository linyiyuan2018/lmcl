var d = new Date();
function Request(strName){
var strHref = location.href;
var intPos = strHref.indexOf("?");
var strRight = strHref.substr(intPos + 1);
var arrTmp = strRight.split("&");
for(var i = 0; i < arrTmp.length; i++) {
var arrTemp = arrTmp[i].split("=");
if(arrTemp[0].toUpperCase() == strName.toUpperCase()) return arrTemp[1];
}
return "";
}
var ident=Request("ident");
if(ident=="mtg")
var live = '1928284761648059_192746_mtg';
if(ident=="mtg")
var tvname = 'MCTV G';
if(ident=="mtg")
document.getElementById('live_tv_name').innerHTML = '-MCTV G';
if(ident=="mtg")
var baseid = "NV2GOX3NMN2HM3TFOR3W64TLL5WGS5TFMRQW43LVL4YTCNBVGE2A===mtvdanmaku";
if(ident=="mth")
var live = '4738329395834058_102948_mth';
if(ident=="mth")
var tvname = 'MCTV H';
if(ident=="mth")
document.getElementById('live_tv_name').innerHTML = '-MCTV H';
if(ident=="mth")
var baseid = "NV2GQX3NMN2HM3TFOR3W64TLL5WGS5TFMRQW43LVL4YTCNBVGE2A====mtvdanmaku";
if(ident=="mts")
var live = '5782929475739202_371746_mts';
if(ident=="mts")
var tvname = 'MCTV T';
if(ident=="mts")
document.getElementById('live_tv_name').innerHTML = '-MCTV T';
if(ident=="mts")
var baseid = "NV2HGX3NMN2HM3TFOR3W64TLL5WGS5TFMRQW43LVL4YTCNBVGE2A====mtvdanmaku";
if(ident=="m4k")
var live = '5837586939582872_402947_m4k';
if(ident=="m4k")
var tvname = 'MCTV G4K';
if(ident=="m4k")
document.getElementById('live_tv_name').innerHTML = '-MCTV G4K';
if(ident=="m4k")
var baseid = "NU2GWX3NMN2HM3TFOR3W64TLL5WGS5TFMRQW43LVL4YTCNBVGE2A====mtvdanmaku";
if(ident=="m8k")
var live = '6549721546343733_867392_m8k';
if(ident=="m8k")
var tvname = 'MCTV G8K';
if(ident=="m8k")
document.getElementById('live_tv_name').innerHTML = '-MCTV G8K';
if(ident=="m8k")
var baseid = "NU4GWX3NMN2HM3TFOR3W64TLL5WGS5TFMRQW43LVL4YTCNBVGE2A====mtvdanmaku";